module.exports = {
    DOMAIN: "https://example.com", // Ganti dengan domain API Anda
    API_KEY: "your_api_key_here",  // Ganti dengan API Key Anda
    OWNER_ID: "123456789"          // Ganti dengan ID pemilik bot
};