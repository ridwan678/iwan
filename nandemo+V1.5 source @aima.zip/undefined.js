const global = {
    superAdmin: [7943237510, 6644450387],
    usernameOwner: "@cellasta",
    botName: "𝙉𝙖𝙣𝙙𝙚𝙢𝙤ી",
    botToken: "7787083055:AAGlvTJJYVFSngqJ5lEt_VwQYD_pTpzcRuA",
    channelLink: "https://t.me/isengaja8",
    preview: 'https://files.catbox.moe/z8wafh.mp4'
}

module.exports = global;